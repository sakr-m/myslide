Hijiyama.R \#5 発表資料
================

これは前田和寛(@kazutan) が[Hijiyama.R \#5](https://atnd.org/events/81359)にて発表した内容の資料などを置いたリポジトリです。

Rの導入とデータ操作
-------------------

- スライド1　https://kazutan.github.io/HijiyamaR5/r-intro.html
- スライド2　https://kazutan.github.io/HijiyamaR5/data_handling.html


R Markdown入門
--------------

- スライド　https://kazutan.github.io/HijiyamaR5/rmd_intro.html

最近のR Markdown関連のお話
--------------------------

- スライド　https://kazutan.github.io/HijiyamaR5/rmd_trend.html

License
-------

<a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons Attribution 4.0 International License</a>.
